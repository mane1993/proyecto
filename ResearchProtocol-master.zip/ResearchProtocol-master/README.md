Latex template for a research protocol (v.1.1, June 10, 2021)
Adapted for:
"Instituto Tecnológico de León"

Alexis Torres-Carbajal modifyed this file from:

Danny Awty-Carroll,  
originally written by 
LianTze Lim (liantze@gmail.com).
This is altacv.cls (v1.1.3, 30 April 2017)


It may be distributed and/or modified under the conditions of the 
LaTeX Project Public License, either version 1.3 of this license or 
(at your option) any later version. The latest version of this 
license is in

   http://www.latex-project.org/lppl.txt

and version 1.3 or later is part of all distributions of LaTeX 
version 2003/12/01 or later.
